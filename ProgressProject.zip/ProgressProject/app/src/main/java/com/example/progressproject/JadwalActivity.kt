package com.example.progressproject

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class JadwalActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_jadwal)
    }
}